### Elephant Interspecific Posture Project: NetFACS analysis of elephant-human interaction posture data - specificity and probability networks - individual activities
### Based on script by Kate Lewis NetFACS analysis of EquiFACS horse-horse data - specificity and probability networks - with ind. behaviours https://osf.io/tymvr
# Created on: 31/01/2026 
# Updated on: 05/08/2026
# Owner: Tapinder Sidhu


###################################################################################################################

## Prepare environment ##

# Clear environment
rm(list=ls())

###################################################################################################################

## Install packages ##


# only need to install package once
# will install development version of NetFACS: v0.5.0.9001
remove.packages("NetFACS")
#install.packages("remotes")
library(remotes)
remotes::install_github("NetFACS/NetFACS", ref = "73c2a29b")

#install.packages("tidyverse")
library(tidyverse)
library(NetFACS)
library(readxl)
library(ggraph)

###################################################################################################################

## Upload and upsample data ##

# upload all data (in one df) 
all.data <- read.csv("Data/InterspecificPosture_ForNetFACS.csv")

# UPSAMPLE - as imbalanced number of observations per group causes specificity results to be biased

# First check current numbers of each behaviour
head(all.data %>% count(Activity), n=22)
#Activity   n
#1          Charge 472
#2    Full Retreat 490
#3    Retreat From 387
#4 Threat Approach 118

# randomly upsample minority conditions to have the same number of observations as the majority condition

set.seed(3)

all.data.upsampled <- upsample(all.data, 
                               condition = all.data$Activity)
# check it has worked
print(all.data.upsampled %>% count(Activity), n=22) # all conditions now have 490 observations


# SPLIT all.data.upsampled into seperate DATA AND INFO dfs (needed in this format for running multi.facs)
au.info <- all.data.upsampled %>% select(X:Activity)
au.data <- all.data.upsampled %>% select(EFold:HfStToe)


# check same number of rows in each
nrow(au.data)
nrow(au.info)
#1960

# convert data to numeric, NA coercion is ok
au.data <- 
  au.data %>% 
  mutate(across(everything(), as.numeric)) %>% 
  as.matrix()

head(au.data)


####################################################################################################################



##################################### ANALYSIS BY BEHAVIOURS ############################################################


#### WITH MULTIFACS ####


set.seed(20266) 
# added myself - ensures same random distribution each time I run code (I am using the same set.seed value in unweighted and weighted scripts and ambo apnr only scripts,
# = direct comparison using the same random stream ensures differences come only from the data, not from stochastic variation,
# i.e., testing elephant postures in unweighted vs weighted dataset under identical bootstrap/permutation conditions)


# this code is what netfacs.multiple does under the hood
# I'm coding it manually here because netfacs.multiple does not currently work when the data has NAs.
## HIDE FOR NOW SO IT DOES NOT RUN AGAIN ##
conditions <- sort(unique(au.info$Activity))
ran.trials <- 1000
multi.facs <- lapply(conditions, function(x) {
  xx <- netfacs_na(
    data = au.data,
    condition = au.info$Activity,
    test.condition = x,
    ran.trials = ran.trials, 
    combination.size = 2,
    random.level = au.info$RC,            # add record code as random level
    use_parallel = TRUE,
    n_cores = parallel::detectCores()-1
  )
  return(xx)
})
names(multi.facs) <- conditions
# set class and attributes
multi.facs <- structure(
  multi.facs, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facs, file="multi.facs.activityspecIP.rds")

# load multi.facs object
multi.facs <- readRDS("multi.facs.activityspecIP.rds")

# extract overall results with pvalues
(resAcSpecIP <- netfacs_extract(multi.facs))
view(resAcSpecIP)

write.csv(resAcSpecIP, "Data/NetFACSExtractMultiFacsResActivitiesforSpecificityIP.csv")



##########################################################################################################

#### CALCULATING SPECIFICITY ####



library(dplyr)

# netfacs() function no longer calculates specificity, so it has to be calculated separately
# imbalanced number of observations per group causes specificity results to be biased

# Check we still have same number for each behaviour (from upsampling earlier)
print(au.info %>% count(Activity), n=22) # yes, 490 obs for each behaviour


# calculate specificity from netfacs results 
set.seed(4)
sp.behav <- specificity(
  multi.facs, 
  combination.size = 2, 
)


# view combinations with top 5 highest specificity per context
sp1 <- sp.behav %>% 
  group_by(condition) %>% 
  slice_max(order_by = specificity, n = 5)

# view combinations with top 5 observed probabilities per context
sp.behav %>% 
  group_by(condition) %>% 
  slice_max(order_by = observed.prob, n = 5)

# consider filtering for combinations that are common AND have high specificity
sp3<- sp.behav %>% 
  filter(
    observed.prob >= 0.25, # combinations present in at least 25% of obs
    specificity >= 0.5, 
  ) 

# save spec results
write.csv(sp.behav, "Data/SpecifictyBehIPRes.csv")


################################################################################

#### SPECIFICITY VIOLIN PLOTS ####


# summarise specificity results
sp.behavIP.summary <- 
  sp.behav %>% 
  # optional filtering. 
  # The combination count should be at least the same number as the number of conditions. Otherwise an AU combination that is only observed once will have a specificity of 1, but only because it never had the chance to be observed in another context.
  filter(
    observed.prob >= 0.10, # combination observed in >= 10% of cases
    count >= length(unique(sp.behav$condition))
  ) %>%
  group_by(condition) %>%
  summarise(across(
    specificity,
    list(
      mean = mean,
      median = median,
      min = min,
      max = max,
      sd = sd,
      n = ~n()
    ),
    .names = "{.fn}"
  ), .groups = "keep")

View(sp.behavIP.summary)
write.csv(sp.behavIP.summary, "Data/NetFACSSpecificityActivitiesIP.csv")


SpecActIP.plot <- sp.behav %>%
  # use same filter as for the summary
  filter(
    observed.prob >= 0.1, 
    count >= length(unique(sp.behav$condition))
  ) %>%
  # plot
  ggplot(aes(condition, specificity, fill=condition)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"),
        axis.title = element_text(size = 15, face = "bold"),
        axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)),
        axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0)),
        axis.text = element_text(size = 10, color = "black")) +
  geom_violin(alpha = 0.2,
              show.legend = FALSE) +
  geom_point(position = position_jitter(width = 0.3),
             aes(color = condition),
             show.legend = FALSE,
             alpha = 0.15) +
  geom_point(data = sp.behavIP.summary,
             aes(condition, mean),
             show.legend = FALSE,
             fill = "white",
             color = "black",
             shape = 23,
             size = 3.5) +
  xlab("Behaviour") +
  ylab("Specificity") +
  scale_x_discrete(
    limits = c("Threat Approach", "Charge", "Full Retreat", "Retreat From"),
    labels = c("Threat Approach", "Charge", "Full Retreat", "Retreat From")
  ) +
  scale_fill_manual(values = c("Threat Approach" = "#9F59E6","Charge" = "#C77CFF",  
                               "Full Retreat" = "#84C800", "Retreat From" = "#B8E46E")) +
  scale_color_manual(values = c("Threat Approach" = "#9F59E6","Charge" = "#C77CFF",  
                                "Full Retreat" = "#84C800", "Retreat From" = "#B8E46E"))


# Save the plot
ggsave("Figures/SpecificityActivitiesViolinPlotIP.png", plot = SpecActIP.plot, width = 10, height = 8, dpi = 300)



################################################################################




# CREATE CUSTOM PLOTS

min_prob <- 0.1

d2 <- 
  sp.behav |> 
  rename(context = condition,
         count = count) %>%
  # keep single AUs only
  filter(!str_detect(combination, "_")) |> 
  filter(
    combination.size == 1,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, specificity) 

gl <- 
  d2 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()

au_color="steelblue"
context_color = "salmon"

gl2 <-
  gl %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout first so the we can access the coordinates
gl2b <-
  gl2 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr"
  )

edge_color = "#404040"
context_color = "#0f85a0"
au_color = "#ed8b00"
node_text_size = 4
theme_text_size = 14

gl3 <-
  gl2b %>%
  ggraph() +
  geom_edge_fan(
    aes(alpha = specificity,
        width = specificity),
    colour = edge_color,
  ) +
  geom_node_label(
    aes(label = name,
        fontface = shape),
    color = gl2b$color,
    size = node_text_size,
    show.legend = FALSE
  ) +
  theme_graph(
    base_family = "sans"
  ) +
  scale_edge_alpha_continuous(
    name = "Specificity:",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Specificity:",
    range = c(1, 3.5),
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  theme(
    plot.title = element_text(
      face = "plain",
      size = theme_text_size,
      vjust = -5),
    legend.text = element_text(size = theme_text_size),
    legend.title = element_text(size = theme_text_size),
    plot.margin = grid::unit(c(-0,-0,-0,-0), "mm"),
    legend.position = c(0.85, 0.15)
  )

# Save the plot
ggsave("Figures/SpecificityNetPlotActivitiesIP.png", plot = gl3, width = 10, height = 8, dpi = 300)


#overlap_net_patch <-
#  patchwork::wrap_plots(gl3) +
#  patchwork::plot_layout(ncol = 1, guides = "collect") &
# theme(legend.position = "bottom")


################################################################################

### EXTRACT SIG AU/ADs FOR EACH ACTIVITY ####



## AGONISTIC ##

H_Ch.pus1 <- netfacs_extract(
  netfacs.data = multi.facs$Charge,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Ch.pus1)
write.csv(H_Ch.pus1, "Data/NetFACSChargespecIP.pus.csv")


H_AppTh.pus1 <- netfacs_extract(
  netfacs.data = multi.facs$'Threat Approach',
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_AppTh.pus1)
write.csv(H_AppTh.pus1, "Data/NetFACSAppThSpecIP.pus.csv")


## Evasive ##

FullRetreat.pus1 <- netfacs_extract(
  netfacs.data = multi.facs$'Full Retreat',
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(FullRetreat.pus1)
write.csv(FullRetreat.pus1, "Data/NetFACSFullRetreatspecIP.csv")


RetreatFrom.pus1 <- netfacs_extract(
  netfacs.data = multi.facs$'Retreat From',
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(RetreatFrom.pus1)
write.csv(RetreatFrom.pus1, "Data/NetFACSRetreatFromspecIP.csv")

################################################################################


# CREATE CUSTOM PLOTS AGAIN FOR PAIRS ####

min_prob <- 0.1

d3 <- 
  sp.behav |> 
  rename(context = condition,
         count = count) %>%
  filter(
    combination.size == 2,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, specificity) 

gl1 <- 
  d3 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()

au_color="steelblue"
context_color = "salmon"

gl3 <-
  gl1 %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout first so the we can access the coordinates
gl3b <-
  gl3 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr",
    niter = 5000
  )

#space layout more
gl3b$x <- gl3b$x * 1.5
gl3b$y <- gl3b$y * 1.5

edge_color = "#404040"
context_color = "#0f85a0"
au_color = "#ed8b00"
node_text_size = 4
theme_text_size = 14

gl4 <-
  gl3b %>%
  ggraph() +
  geom_edge_fan(
    aes(alpha = specificity,
        width = specificity),
    colour = edge_color,
  ) +
  geom_node_label(
    aes(label = name,
        fontface = shape),
    color = gl3b$color,
    size = node_text_size,
    show.legend = FALSE
  ) +
  theme_graph(
    base_family = "sans"
  ) +
  scale_edge_alpha_continuous(
    name = "Specificity:",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Specificity:",
    range = c(1, 3.5),
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  theme(
    plot.title = element_text(
      face = "plain",
      size = theme_text_size,
      vjust = -5),
    legend.text = element_text(size = theme_text_size),
    legend.title = element_text(size = theme_text_size),
    plot.margin = grid::unit(c(-0,-0,-0,-0), "mm"),
    legend.position = c(0.05, 0.85)
  )

# Save the plot
ggsave("Figures/SpecificityNetPlotActivitiesIPPairs.png", plot = gl4, width = 16, height = 12, dpi = 300)


#overlap_net_patch <-
#  patchwork::wrap_plots(gl3) +
#  patchwork::plot_layout(ncol = 1, guides = "collect") &
# theme(legend.position = "bottom")


################################################################################

### EXTRACT SIG AU/ADs FOR EACH ACTIVITY ####



## AGONISTIC ##

H_Ch.pus2 <- netfacs_extract(
  netfacs.data = multi.facs$Charge,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Ch.pus2)
write.csv(H_Ch.pus2, "Data/NetFACSChargespecIPPairs.pus.csv")


H_AppTh.pus2 <- netfacs_extract(
  netfacs.data = multi.facs$'Threat Approach',
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_AppTh.pus2)
write.csv(H_AppTh.pus2, "Data/NetFACSAppThSpecIPPairs.pus.csv")


## Evasive ##

FullRetreat.pus2 <- netfacs_extract(
  netfacs.data = multi.facs$'Full Retreat',
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(FullRetreat.pus2)
write.csv(FullRetreat.pus2, "Data/NetFACSFullRetreatspecIPPairs.csv")


RetreatFrom.pus2 <- netfacs_extract(
  netfacs.data = multi.facs$'Retreat From',
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(RetreatFrom.pus2)
write.csv(RetreatFrom.pus2, "Data/NetFACSRetreatFromspecIPPairs.csv")