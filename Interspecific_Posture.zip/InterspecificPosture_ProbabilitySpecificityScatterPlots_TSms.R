### Elephant Interspecific Posture Project: Probability x Specificity scatter
### Identifies single posture-units and posture-unit PAIRS that occur with both
### high probability AND high specificity within each interaction context / behaviour.
###
### Probability (observed.prob), count and pvalue are taken from the NetFACS extract files.
### Specificity is taken from the specificity files.
### The two are joined on condition + combination.
# Owner: Tapinder Sidhu
# Created on: 05/08/2026
# Updated on: 07/08/2026 

################################################################################

## Prepare environment ##

# Clear environment
rm(list=ls())

################################################################################

## Load packages ##

# ggrepel is used so that the labels for high-high units do not overlap each other

library(tidyverse)
library(dplyr)
library(ggrepel)

################################################################################

################################################################################
# DEFINE ANALYSIS SETTINGS ####
#
# Edit these values before running the script if needed.
#
# minimum_count:                 removes very rare cases before plotting
# maximum_pvalue:                keeps only significantly enriched cases
# minimum_probability_threshold: horizontal "high probability" cut-off
# minimum_specificity_threshold: vertical "high specificity" cut-off
# combination_sizes_to_keep:     1 = single units, 2 = pairs (3 = triples excluded)

minimum_count                 <- 5
maximum_pvalue                <- 0.01
minimum_probability_threshold <- 0.25
minimum_specificity_threshold <- 0.75
combination_sizes_to_keep     <- c(1, 2)

# Robustness: high-high units displayed by fewer than this proportion of the
# individuals present in that context/behaviour are flagged on the figure and
# in the tables (post-hoc individual-spread check).
minimum_individual_proportion <- 0.50

# Raw event-level data (one row per event) used to count how many individuals
# displayed each unit. Must contain the ID column, the posture-unit columns,
# and the condition columns (CSubcat for context, Activity for behaviour).
raw_data_file <- "Data/InterspecificPosture_ForNetFACS.csv"

# Panel order for each level (also controls facet order).
context_condition_levels   <- c("Aggressive", "Evasive")
behaviour_condition_levels <- c("Threat Approach", "Charge", "Retreat From", "Full Retreat")


# AESTHETIC SETTINGS ####
#
# A restrained two-colour scheme. Shape (circle vs triangle) carries the
# single-unit / pair distinction, so colour is free: a cool dusky blue for the
# whole data cloud, with a warm accent reserved for the high-high quadrant so
# the diagnostic region and its labels stand out. Edit these to restyle.


point_fill_colour      <- "#3E6B84"  # dusky blue for all posture points
highlight_fill_colour  <- "#E9C46A"  # warm gold shading for the high-high quadrant
highlight_label_colour <- "#9C4A1A"  # burnt sienna for the high-high labels
threshold_line_colour  <- "#9C978D"  # soft neutral for the threshold lines
lowspread_ring_colour  <- "#B23A48"  # muted red ring for low individual-spread units
ink_colour             <- "#2B2B2B"  # near-black for titles and outlines
axis_colour            <- "#4A4A4A"  # muted grey for axis lines and tick text




# DEFINE A FUNCTION TO BUILD THE PLOT DATA ####
#
# This function:
# 1. Reads the probability file (NetFACS extract) and takes probability, count,
#    pvalue and combination size from it.
# 2. Reads the specificity file and takes specificity from it.
# 3. Joins the two on condition + combination.
# 4. Applies the combination-size, pvalue and count filters.
# 5. Counts how many individuals displayed each unit (from the raw event data),
#    using the individuals present in that condition as the denominator.
# 6. Flags the high-probability AND high-specificity cases, flags any high-high
#    unit with low individual spread, and adds labels.

# Count individuals displaying one combination within one condition.
# A combination is "displayed" in an event if all of its elements are active (== 1).
# The denominator is the number of individuals present in that condition.
count_individuals_for_unit <- function(raw_data, condition_column, condition_value, combination) {
  elements <- unlist(strsplit(as.character(combination), "_", fixed = TRUE))
  in_condition <- raw_data[raw_data[[condition_column]] == condition_value, , drop = FALSE]
  total_individuals <- length(unique(in_condition$ID))
  element_sums <- rowSums(in_condition[, elements, drop = FALSE] == 1)
  displayed <- !is.na(element_sums) & element_sums == length(elements)
  tibble(
    n_individuals     = length(unique(in_condition$ID[displayed])),
    total_individuals = total_individuals
  )
}

prepare_plot_data <- function(probability_file,
                              specificity_file,
                              condition_levels,
                              raw_condition_column) {
  
  # probability, count and pvalue come from the NetFACS extract file
  probability_values <- read.csv(probability_file) %>%
    select(condition, combination, combination.size, count, observed.prob, pvalue)
  
  # specificity comes from the specificity file
  specificity_values <- read.csv(specificity_file) %>%
    select(condition, combination, specificity)
  
  # join the two sources on condition + combination
  joined_data <- probability_values %>%
    inner_join(specificity_values, by = c("condition", "combination"))
  
  # report if any rows failed to match across the two files
  unmatched <- nrow(probability_values) - nrow(joined_data)
  if (unmatched != 0) {
    message(unmatched,
            " row(s) in the probability file had no matching specificity value and were dropped.")
  }
  
  # apply filters
  filtered_data <- joined_data %>%
    filter(
      combination.size %in% combination_sizes_to_keep,
      pvalue <= maximum_pvalue,
      count  >= minimum_count
    )
  
  # count individuals displaying each retained unit (from the raw event data)
  raw_data <- read.csv(raw_data_file)
  spread_counts <- purrr::pmap_dfr(
    list(condition = as.character(filtered_data$condition),
         combination = filtered_data$combination),
    function(condition, combination) {
      count_individuals_for_unit(raw_data, raw_condition_column, condition, combination)
    }
  )
  
  # attach spread counts and build the plotting columns
  bind_cols(filtered_data, spread_counts) %>%
    mutate(
      prop_individuals = n_individuals / total_individuals,
      # readable labels for the two combination sizes
      posture_type = factor(
        combination.size,
        levels = c(1, 2),
        labels = c("Single unit", "Pair")
      ),
      # flag the high-probability AND high-specificity cases (top-right quadrant)
      high_high = observed.prob >= minimum_probability_threshold &
        specificity   >= minimum_specificity_threshold,
      # flag high-high units displayed by only a few individuals
      low_spread = high_high & prop_individuals < minimum_individual_proportion,
      # label high-high cases only; mark low-spread ones with a dagger
      plot_label = ifelse(
        high_high,
        ifelse(low_spread, paste0(combination, " \u2020"), combination),
        NA_character_
      ),
      # order the panels
      condition = factor(condition, levels = condition_levels)
    )
}



# DEFINE A FUNCTION TO CREATE THE PLOT ####
#
# The shaded rectangle marks the high-high quadrant (top-right).
# Dashed reference lines mark the two thresholds.
# Point area is proportional to count; shape distinguishes single units from pairs.


make_probability_specificity_plot <- function(plot_data, panel_columns) {
  
  ggplot(plot_data, aes(x = specificity, y = observed.prob)) +
    # shaded high-high quadrant
    annotate(
      "rect",
      xmin = minimum_specificity_threshold, xmax = Inf,
      ymin = minimum_probability_threshold, ymax = Inf,
      fill = highlight_fill_colour, alpha = 0.22
    ) +
    # threshold reference lines
    geom_vline(xintercept = minimum_specificity_threshold,
               linetype = "dashed", colour = threshold_line_colour) +
    geom_hline(yintercept = minimum_probability_threshold,
               linetype = "dashed", colour = threshold_line_colour) +
    # points; shape distinguishes single units from pairs (size fixed, not mapped to count)
    geom_point(
      aes(shape = posture_type),
      size = 2.6, fill = point_fill_colour, colour = ink_colour, stroke = 0.3, alpha = 0.85
    ) +
    # ring around high-high units displayed by only a few individuals (low spread)
    geom_point(
      data = function(d) dplyr::filter(d, low_spread),
      aes(shape = posture_type),
      size = 5.2, fill = NA, colour = lowspread_ring_colour, stroke = 1.1,
      show.legend = FALSE
    ) +
    # labels for the high-high units only
    geom_text_repel(
      aes(label = plot_label),
      size = 3.2,
      colour = "black",
      fontface = "bold",
      bg.color = "white",        # white halo so text stays legible over points
      bg.r = 0.18,               # halo thickness
      box.padding = 0.6,         # push labels further from one another
      point.padding = 0.4,       # push labels off the points themselves
      force = 3,                 # stronger repulsion to break up clusters
      force_pull = 0.5,
      min.segment.length = 0,    # always draw a connector
      segment.color = "grey55",
      segment.size = 0.3,
      max.overlaps = Inf,
      seed = 2026,               # reproducible label placement
      show.legend = FALSE
    ) +
    # one panel per condition
    facet_wrap(~ condition, ncol = panel_columns) +
    # scales
    scale_shape_manual(
      name = "Posture type",
      values = c("Single unit" = 21, "Pair" = 24)   # 21 = filled circle, 24 = filled triangle
    ) +
    scale_x_continuous(limits = c(0, 1.02), breaks = seq(0, 1, 0.25),
                       expand = expansion(mult = c(0.03, 0.10))) +
    scale_y_continuous(limits = c(0, NA),
                       expand = expansion(mult = c(0.02, 0.12))) +
    labs(
      x = "Specificity",
      y = "Probability",
      caption = paste0(
        "\u2020 / red ring: high-high unit displayed by fewer than ",
        round(minimum_individual_proportion * 100),
        "% of individuals in that context"
      )
    ) +
    theme_classic(base_size = 13) +
    theme(
      strip.background = element_blank(),
      strip.text   = element_text(face = "bold", size = 12, colour = ink_colour),
      axis.title   = element_text(colour = ink_colour),
      axis.text    = element_text(colour = axis_colour),
      axis.line    = element_line(colour = axis_colour),
      axis.ticks   = element_line(colour = axis_colour),
      legend.title = element_text(face = "bold", size = 10, colour = ink_colour),
      legend.text  = element_text(colour = axis_colour),
      legend.position = "right",
      plot.caption = element_text(colour = axis_colour, size = 9, hjust = 0)
    ) +
    # make the shape legend keys a readable size and filled
    guides(shape = guide_legend(override.aes = list(size = 3.5, fill = point_fill_colour)))
}

################################################################################

##### CONTEXT LEVEL PLOT: Aggressive vs Evasive --------------------------------

# probability from NetFACSExtractMultiFacsContextIP, specificity from SpecifictyContextsIPRes
context_plot_data <- prepare_plot_data(
  probability_file = "Data/NetFACSExtractMultiFacsContextIP.csv",
  specificity_file = "Data/SpecifictyContextsIPRes.csv",
  condition_levels = context_condition_levels,
  raw_condition_column = "CSubcat"
)

context_plot <- make_probability_specificity_plot(
  plot_data = context_plot_data,
  panel_columns = 2
)

ggsave(
  filename = "Figures/ProbabilitySpecificityScatter_Context.png",
  plot = context_plot,
  width = 10, height = 5, dpi = 300
)

ggsave(
  filename = "Figures/ProbabilitySpecificityScatter_Context.pdf",
  plot = context_plot,
  width = 10, height = 5
)



##### BEHAVIOUR LEVEL PLOT: Threat Approach, Charge, Retreat From, Full Retreat ----

# probability from NetFACSExtractMultiFacsIP, specificity from SpecifictyBehIPRes
behaviour_plot_data <- prepare_plot_data(
  probability_file = "Data/NetFACSExtractMultiFacsIP.csv",
  specificity_file = "Data/SpecifictyBehIPRes.csv",
  condition_levels = behaviour_condition_levels,
  raw_condition_column = "Activity"
)

behaviour_plot <- make_probability_specificity_plot(
  plot_data = behaviour_plot_data,
  panel_columns = 2   # 4 behaviours shown as a 2 x 2 grid; set to 4 for a single row
)

ggsave(
  filename = "Figures/ProbabilitySpecificityScatter_Behaviour.png",
  plot = behaviour_plot,
  width = 10, height = 9, dpi = 300
)

ggsave(
  filename = "Figures/ProbabilitySpecificityScatter_Behaviour.pdf",
  plot = behaviour_plot,
  width = 10, height = 9
)




# BUILD AND SAVE TABLES --------------------------------------------------------
#
# For each level this produces two files:
# 1. A raw table  (HighHighUnits_<level>.csv):
#    - one row per high-high unit, full-precision values, for own records.
#
# The main tables contain the HIGH-HIGH units only (the answer to the question).
# The full filtered set (all significant single units and pairs, high-high or
# not) is also saved as a supplementary table for completeness.


# Build, save and print the tables for one level
build_high_high_tables <- function(plot_data, level_label, file_stub) {
  
  # 1. Raw high-high table (full precision)
  high_high_raw <- plot_data %>%
    filter(high_high) %>%
    select(condition, combination, posture_type,
           observed.prob, specificity, count, pvalue,
           n_individuals, total_individuals, prop_individuals, low_spread) %>%
    arrange(condition, desc(observed.prob))
  
  write.csv(
    high_high_raw,
    paste0("Data/HighHighUnits_", file_stub, ".csv"),
    row.names = FALSE
  )
  
 
  
  # 3. Supplementary table: the full filtered set (high-high flagged)
  full_filtered <- plot_data %>%
    select(condition, combination, posture_type,
           observed.prob, specificity, count, pvalue,
           n_individuals, total_individuals, prop_individuals,
           high_high, low_spread) %>%
    arrange(condition, desc(high_high), desc(observed.prob))
  
  write.csv(
    full_filtered,
    paste0("Data/FilteredUnits_", file_stub, "_supplementary.csv"),
    row.names = FALSE
  )
  

}

build_high_high_tables(context_plot_data,   "Context",   "Context")
build_high_high_tables(behaviour_plot_data, "Behaviour", "Behaviour")