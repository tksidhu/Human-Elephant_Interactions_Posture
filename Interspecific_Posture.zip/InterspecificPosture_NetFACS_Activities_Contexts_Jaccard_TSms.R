### Elephant Interspecific Posture Project: NetFACS analysis of elephant-human interaction posture data by activity and context
### Based on script by Kate Lewis NetFACS analysis of EquiFACS horse-horse data - by individual context https://osf.io/zmsvx/
# Created on: 31/01/2026
# Updated on: 05/06/2026
# Owner: Tapinder Sidhu

################################################################################

## Prepare environment ##

# Clear environment
rm(list=ls())

################################################################################

## Install packages ##
# will install development version of NetFACS: v0.5.0.9001
remove.packages("NetFACS")
remotes::install_github("NetFACS/NetFACS", ref = "73c2a29b")

library(tidyverse)
library(dplyr)
library(NetFACS)
library(tidygraph)
library(ggraph)

################################################################################

# upload data
full.data <- read.csv("Data/InterspecificPosture_ForNetFACS.csv")

################################################################################

# split data
au.data <- full.data %>% select(EFold:HfStToe)
au.info <- full.data %>% select(X:Activity)

# check rows match
nrow(au.data) 
nrow(au.info)

# convert data to numeric, NA coercion is ok
au.data <- 
  au.data %>% 
  mutate(across(everything(), as.numeric)) %>% 
  as.matrix()

head(au.data)



################################################################################




##################################### ANALYSIS BY BEHAVIOURAL GROUPS ###########

#### WITH MULTIFACS ####


set.seed(2026) # ensures same random distribution each time I run code
# this code is what netfacs.multiple does under the hood
# I'm coding it manually here because netfacs.multiple does not currently work when the data has NAs.
conditions <- sort(unique(au.info$Activity)) # Extracts and sorts all unique behavioural activities
ran.trials <- 1000 # sets number of random permutations (used for bootstrap sig testing)
multi.facs <- lapply(conditions, function(x) {
  xx <- netfacs_na( # all of this loops through each activity and netfacs_na() is custom version of main NetFACS func to handle NAs
    data = au.data,
    condition = au.info$Activity, # vector of behavioural categories for each row
    test.condition = x, # the current condition being tested against all others
    ran.trials = ran.trials, 
    combination.size = 2,
    random.level = au.info$RC,            # add record code as random level
    use_parallel = FALSE,
    n_cores = parallel::detectCores()-1 # uses all but one core for parallel processing
  )
  return(xx) 
}) 
names(multi.facs) <- conditions # Names each element in multi.facs according to its behavioural condition
# set class and attributes
multi.facs <- structure(
  multi.facs, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facs, file="multi.facsIP.rds")

# load multi.facs object
multi.facs <- readRDS("multi.facsIP.rds")


# extract overall results with pvalues
(resupdateIP <- netfacs_extract(multi.facs))
view(resupdateIP)

write.csv(resupdateIP, "Data/NetFACSExtractMultiFacsIP.csv")

################################################################################


### EXTRACT SIG AU/ADs FOR EACH BEHAVIOUR ####


## AGRESSIVE INTERACTIONS ##


H_Charge.pus <- netfacs_extract(
  netfacs.data = multi.facs$Charge,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Charge.pus)
write.csv(H_Charge.pus, "Data/NetFACSH_Charge.pus.csv")

H_Th_App.pus <- netfacs_extract(
  netfacs.data = multi.facs$`Threat Approach`,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Th_App.pus)
write.csv(H_Th_App.pus, "Data/NetFACSH_Th_App.pus.csv")



## EVASIVE INTERACTIONS ##


H_FullRetreat.pus <- netfacs_extract(
  netfacs.data = multi.facs$`Full Retreat`,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_FullRetreat.pus)
write.csv(H_FullRetreat.pus, "Data/NetFACSH_FullRetreat.pus.csv")


H_RetreatFrom.pus <- netfacs_extract(
  netfacs.data = multi.facs$`Retreat From`,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_RetreatFrom.pus)
write.csv(H_RetreatFrom.pus, "Data/NetFACSH_RetreatFrom.pus.csv")


### EXTRACT SIG AU/ADs FOR EACH BEHAVIOURA PAIRS ####


## AGRESSIVE INTERACTIONS ##


H_Charge2.pus <- netfacs_extract(
  netfacs.data = multi.facs$Charge,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Charge2.pus)
write.csv(H_Charge2.pus, "Data/NetFACSH_ChargePairs.pus.csv")

H_Th_App2.pus <- netfacs_extract(
  netfacs.data = multi.facs$`Threat Approach`,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Th_App2.pus)
write.csv(H_Th_App2.pus, "Data/NetFACSH_Th_AppPairs.pus.csv")



## EVASIVE INTERACTIONS ##


H_FullRetreat2.pus <- netfacs_extract(
  netfacs.data = multi.facs$`Full Retreat`,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_FullRetreat2.pus)
write.csv(H_FullRetreat2.pus, "Data/NetFACSH_FullRetreatPairs.pus.csv")


H_RetreatFrom2.pus <- netfacs_extract(
  netfacs.data = multi.facs$`Retreat From`,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_RetreatFrom2.pus)
write.csv(H_RetreatFrom2.pus, "Data/NetFACSH_RetreatFromPairs.pus.csv")

################################################################################


#### NETWORK PLOTS FOR EACH BEHAVIOUR ############



##### AGRESSIVE INTERACTIONS #####

# CHARGE #

H_Charge.net <- 
  netfacs_network(
    multi.facs$Charge, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(H_Charge.net, 
             plot.bubbles = TRUE)
network_plot(H_Charge.net)


g <- 
  H_Charge.net %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  # keep only connections that are significant
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

H_ChargeNet.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Charge Network")


jpeg("Figures/H_ChargeNet.jpeg")
H_ChargeNet.plot
dev.off()


# H_Th_App #

H_Th_App.net <- 
  netfacs_network(
    multi.facs$`Threat Approach`, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(H_Th_App.net, 
             plot.bubbles = TRUE)
network_plot(H_Th_App.net)


g <- 
  H_Th_App.net %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01)%>%
  # remove nodes that have become isolated after edge filtering
  activate(nodes) %>%
  filter(!node_is_isolated()) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

H_ThreatAppNet.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Threat Approach Network")


jpeg("Figures/H_ThreatAppNet.jpeg")
H_ThreatAppNet.plot
dev.off()



##### EVASIVE INTERACTIONS #####

H_FullRetreat.net <- 
  netfacs_network(
    multi.facs$`Full Retreat`, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(H_FullRetreat.net, 
             plot.bubbles = TRUE)
network_plot(H_FullRetreat.net)


g <- 
  H_FullRetreat.net %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>%
  activate(edges) %>%
  filter(pvalue <= 0.01)%>%
  # remove nodes that have become isolated after edge filtering
  activate(nodes) %>%
  filter(!node_is_isolated()) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

H_FullRetreatNet.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Full Retreat Network")


jpeg("Figures/H_FullRetreatNet.jpeg")
H_FullRetreatNet.plot
dev.off()


H_RetreatFrom.net <- 
  netfacs_network(
    multi.facs$`Retreat From`, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(H_RetreatFrom.net, 
             plot.bubbles = TRUE)
network_plot(H_RetreatFrom.net)


g <- 
  H_RetreatFrom.net %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>%
  activate(edges) %>%
  filter(pvalue <= 0.01)%>%
  # remove nodes that have become isolated after edge filtering
  activate(nodes) %>%
  filter(!node_is_isolated()) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

H_RetreatFromNet.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Retreat From Network")


jpeg("Figures/H_RetreatFromNet.plot.jpeg")
H_RetreatFromNet.plot
dev.off()

################################################################################
#### ADDED BY TS: SAME AGAIN FOR AGRESSIVE AND EVASIVE ####

#### WITH MULTIFACS ####

set.seed(2026)

conditionsC <- sort(unique(au.info$CSubcat)) # Extracts and sorts all unique Context Subcatagories
ran.trials <- 1000 # sets number of random permutations (used for bootstrap sig testing)
multi.facsC <- lapply(conditionsC, function(x) {
  xx <- netfacs_na( # all of this loops through each CSubcat and netfacs_na() is custom version of main NetFACS func to handle NAs
    data = au.data,
    condition = au.info$CSubcat, # vector of context categories for each row
    test.condition = x, # the current condition being tested against all others
    ran.trials = ran.trials, 
    combination.size = 2, 
    random.level = au.info$RC,            # add record code as random level
    use_parallel = FALSE,
    n_cores = parallel::detectCores()-1 # uses all but one core for parallel processing
  )
  return(xx) 
}) 
names(multi.facsC) <- conditionsC # Names each element in multi.facs according to its context condition
# set class and attributes
multi.facsC <- structure(
  multi.facsC, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facsC, file="multi.facsIPC.rds")

# load multi.facs object
multi.facsC <- readRDS("multi.facsIPC.rds")


# extract overall results with pvalues
(resC <- netfacs_extract(multi.facsC))
view(resC)

write.csv(resC, "Data/NetFACSExtractMultiFacsContextIP.csv")

########################################################################################


### EXTRACT SIG AU/ADs FOR EACH CONTEXT ####


## AGGRESSIVE INTERACTIONS ##

H_Ag.pus <- netfacs_extract(
  netfacs.data = multi.facsC$Aggressive,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Ag.pus)
write.csv(H_Ag.pus, "Data/NetFACSH_Ag.pus.csv")

H_Ag.pus <- netfacs_extract(
  netfacs.data = multi.facsC$Aggressive,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Ag.pus)
write.csv(H_Ag.pus, "Data/NetFACSH_AgPAIRS.pus.csv")

## EVASIVE INTERACTIONS ##


H_Evasive.pus <- netfacs_extract(
  netfacs.data = multi.facsC$Evasive,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Evasive.pus)
write.csv(H_Evasive.pus, "Data/NetFACSH_Evasive.pus.csv")

H_Evasive.pus <- netfacs_extract(
  netfacs.data = multi.facsC$Evasive,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(H_Evasive.pus)
write.csv(H_Evasive.pus, "Data/NetFACSH_EvasivePAIRS.pus.csv")

#################################################


#### NETWORK PLOTS FOR EACH CONTEXT ############



#################################################

##### AGGRESSIVE INTERACTIONS #####


H_Ag.net <- 
  netfacs_network(
    multi.facsC$Aggressive, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(H_Ag.net, 
             plot.bubbles = TRUE)
network_plot(H_Ag.net)


g <- 
  H_Ag.net %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

H_AgNet.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(
    aes(label = name),
    color = "firebrick",
    size = 4,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Aggressive Network")


jpeg("Figures/H_AgNet.jpeg")
H_AgNet.plot
dev.off()



##### EVASIVE INTERACTIONS #####

H_Evasive.net <- 
  netfacs_network(
    multi.facsC$Evasive, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(H_Evasive.net, 
             plot.bubbles = TRUE)
network_plot(H_Evasive.net)


g <- 
  H_Evasive.net %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01)%>%
  # remove nodes that have become isolated after edge filtering
  activate(nodes) %>%
  filter(!node_is_isolated()) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

H_EvasiveNet.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(
    aes(label = name),
    color = "firebrick",
    size = 4,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Evasive Network")


jpeg("Figures/H_EvasiveNet.jpeg")
H_EvasiveNet.plot
dev.off()



################################################################################
#### ADDED BY TS: PAIRWISE PROPORTION CALCULATIONS  ####

# Work out overlap of top probability units/combos between behaviour and context networks using Jaccard similarity

# Purpose:
# Calculate overlap in frequently occurring and statistically supported posture units and posture combinations using Jaccard similarity.
#
# Jaccard similarity = size of shared set
# - 1 indicates complete overlap
# - 0 indicates no overlap
#
# The script can be run in two ways:
# 1. Thresholded mode:
#    - count >= minimum_count
#    - observed.prob >= minimum_observed_probability
#    - pvalue <= maximum_pvalue
# 2. Unthresholded mode:
#    - count >= minimum_count only
#
# Comparisons included:
# - Threat Approach vs Charge
# - Retreat From vs Full Retreat
# - Aggressive vs Evasive
#
# Analyses are run separately for:
# - Posture units only (combination.size == 1)
# - Posture combinations only (combination.size > 1)
################################################################################

# DEFINE ANALYSIS SETTINGS -----------------------------------------------------
# Edit these values before running the script if needed.
#
# IMPORTANT TO CHECK AND CHANGE HOWEVER NECESSARY
#
# use_thresholds:
# - TRUE  = apply observed.prob and pvalue thresholds
# - FALSE = ignore observed.prob and pvalue thresholds
#
# minimum_count:
# - removes very rare combinations before analysis
#
# minimum_observed_probability and maximum_pvalue:
# - only used when use_thresholds = TRUE


use_thresholds <- FALSE

minimum_count <- 5
minimum_observed_probability <- 0.10
maximum_pvalue <- 0.01

# CREATE AN OUTPUT LABEL FOR FILE NAMES -----------------------------------------
#
# This creates a short descriptive label that is added to all saved output files,
# so it is immediately obvious whether the results were thresholded or not.

analysis_label <- ifelse(
  use_thresholds,
  "count5_prob0.10_p0.01",
  "count5_no_probability_or_pvalue_thresholds"
)


# DEFINE A FUNCTION TO CALCULATE JACCARD SIMILARITY-----------------------------
#
# This function compares two sets of retained posture items.
#
# Example:
# set A = {a, b, c}
# set B = {b, c, d}
# intersection = {b, c} = 2
# all unique items = {a, b, c, d} = 4
# Jaccard similarity = 2 / 4 = 0.5
#
# If both sets are empty, the function returns NA.

calculate_jaccard_similarity <- function(set_a, set_b) {
  intersection_n <- length(intersect(set_a, set_b))
  union_n <- length(union(set_a, set_b))
  
  if (union_n == 0) {
    return(NA_real_)
  } else {
    return(intersection_n / union_n)
  }
}


# DEFINE A FUNCTION TO CALCULATE OVERLAP FOR ONE PAIRWISE COMPARISON -----------
#
# This function:
# 1. Selects rows belonging to two named conditions
# 2. Optionally applies observed probability and p-value thresholds
# 3. Restricts the data to either:
#    - posture units only, or
#    - posture combinations only
# 4. Extracts the unique retained posture items from each condition
# 5. Calculates:
#    - number of items in each condition
#    - number of shared items
#    - Jaccard similarity
# 6. Returns:
#    - a one-row summary table
#    - a table listing the shared items


calculate_jaccard_overlap <- function(data,
                                      condition_1,
                                      condition_2,
                                      combination_filter,
                                      analysis_level_label) {
  
  # Keep only rows belonging to the first condition
  filtered_condition_1 <- data %>%
    filter(condition == condition_1)
  
  # Keep only rows belonging to the second condition
  filtered_condition_2 <- data %>%
    filter(condition == condition_2)
  
  # If thresholding is enabled, further restrict rows using observed probability
  # and p-value criteria
  if (use_thresholds) {
    filtered_condition_1 <- filtered_condition_1 %>%
      filter(
        observed.prob >= minimum_observed_probability,
        pvalue <= maximum_pvalue
      )
    
    filtered_condition_2 <- filtered_condition_2 %>%
      filter(
        observed.prob >= minimum_observed_probability,
        pvalue <= maximum_pvalue
      )
  }
  
  # Restrict rows to either single posture units or posture combinations,
  # depending on the rule supplied to the function
  filtered_condition_1 <- filtered_condition_1 %>%
    filter({{ combination_filter }})
  
  filtered_condition_2 <- filtered_condition_2 %>%
    filter({{ combination_filter }})
  
  # Extract the unique posture items retained for each condition
  set_1 <- unique(filtered_condition_1$combination)
  set_2 <- unique(filtered_condition_2$combination)
  
  # Identify which posture items are present in both conditions
  shared_items <- intersect(set_1, set_2)
  
  # Create a one-row summary table for this comparison
  summary_table <- tibble(
    comparison_label = paste(condition_1, "vs", condition_2),
    analysis_level = analysis_level_label,
    first_condition = condition_1,
    second_condition = condition_2,
    count_threshold = minimum_count,
    observed_probability_threshold = ifelse(use_thresholds, minimum_observed_probability, NA_real_),
    pvalue_threshold = ifelse(use_thresholds, maximum_pvalue, NA_real_),
    number_of_items_in_first_condition = length(set_1),
    number_of_items_in_second_condition = length(set_2),
    number_of_shared_items = length(shared_items),
    jaccard_similarity = calculate_jaccard_similarity(set_1, set_2)
  )
  
  # Create a table listing the actual shared posture items
  shared_items_table <- tibble(
    comparison_label = paste(condition_1, "vs", condition_2),
    analysis_level = analysis_level_label,
    shared_item = shared_items
  )
  
  # Return both outputs as a list
  list(
    summary = summary_table,
    shared = shared_items_table
  )
}


# LOAD DATA --------------------------------------------------------------------
#
# behaviour_data contains NetFACS outputs for behavioural categories:
# - Threat Approach
# - Charge
# - Retreat From
# - Full Retreat
#
# context_data contains NetFACS outputs for contextual categories:
# - Aggressive
# - Evasive


behaviour_data <- read.csv("Data/NetFACSExtractMultiFacsIP.csv")
context_data   <- read.csv("Data/NetFACSExtractMultiFacsContextIP.csv")


# APPLY THE MINIMUM COUNT FILTER -----------------------------------------------
#
# Rows with count < minimum_count are removed before any overlap analyses.
# This ensures that extremely rare items are excluded.


behaviour_data <- behaviour_data %>%
  filter(count >= minimum_count)

context_data <- context_data %>%
  filter(count >= minimum_count)


# OPTIONAL CHECKS: HOW MANY ROWS REMAIN PER CONDITION? -------------------------
#
# These tables can be printed to inspect how many rows remain after the count
# filter has been applied.

behaviour_data %>%
  count(condition, sort = TRUE)

context_data %>%
  count(condition, sort = TRUE)


# DEFINE THE COMPARISONS TO RUN ------------------------------------------------
#
# Each entry is a pair of condition labels to compare.


behaviour_comparisons <- list(
  c("Threat Approach", "Charge"),
  c("Retreat From", "Full Retreat")
)

context_comparisons <- list(
  c("Aggressive", "Evasive")
)


# DEFINE A FUNCTION TO RUN ALL COMPARISONS FOR A DATASET -----------------------
#
# For each pairwise comparison, the function runs two analyses:
# - posture units only
# - posture combinations only
#
# It then combines all summary outputs and all shared-item outputs into two tidy tables.


run_all_jaccard_comparisons <- function(data, comparisons) {
  
  summary_results <- list()
  shared_results <- list()
  result_index <- 1
  
  for (comparison_pair in comparisons) {
    
    # Analyse single posture units only
    unit_result <- calculate_jaccard_overlap(
      data = data,
      condition_1 = comparison_pair[1],
      condition_2 = comparison_pair[2],
      combination_filter = combination.size == 1,
      analysis_level_label = "Posture units"
    )
    
    # Analyse posture combinations only
    combination_result <- calculate_jaccard_overlap(
      data = data,
      condition_1 = comparison_pair[1],
      condition_2 = comparison_pair[2],
      combination_filter = combination.size > 1,
      analysis_level_label = "Posture combinations"
    )
    
    # Store summary outputs
    summary_results[[result_index]] <- unit_result$summary
    shared_results[[result_index]] <- unit_result$shared
    result_index <- result_index + 1
    
    summary_results[[result_index]] <- combination_result$summary
    shared_results[[result_index]] <- combination_result$shared
    result_index <- result_index + 1
  }
  
  # Combine all stored outputs into two final tables
  list(
    summary = bind_rows(summary_results),
    shared = bind_rows(shared_results)
  )
}


# RUN THE ANALYSES -------------------------------------------------------------
#
# Behaviour-level comparisons and context-level comparisons are run separately,
# then combined into final output tables.

behaviour_results <- run_all_jaccard_comparisons(
  data = behaviour_data,
  comparisons = behaviour_comparisons
)

context_results <- run_all_jaccard_comparisons(
  data = context_data,
  comparisons = context_comparisons
)


# COMBINE ALL RESULTS INTO FINAL OUTPUT TABLES ---------------------------------
#
# summary_table:
# - one row per comparison per analysis level
#
# shared_items_table:
# - one row per shared item


summary_table <- bind_rows(
  behaviour_results$summary,
  context_results$summary
) %>%
  mutate(
    jaccard_similarity = round(jaccard_similarity, 3)
  )

shared_items_table <- bind_rows(
  behaviour_results$shared,
  context_results$shared
)



# SAVE THE MAIN SUMMARY TABLE 


write.csv(
  summary_table,
  paste0(
    "Data/jaccard_similarity_summary_by_comparison_and_analysis_level_",
    analysis_label,
    ".csv"
  ),
  row.names = FALSE
)



# SAVE THE SHARED-ITEMS TABLE

write.csv(
  shared_items_table,
  paste0(
    "Data/jaccard_similarity_shared_posture_items_",
    analysis_label,
    ".csv"
  ),
  row.names = FALSE
)


# CREATE AND SAVE A WIDE SUMMARY TABLE

summary_table_wide <- summary_table %>%
  select(
    comparison_label,
    analysis_level,
    number_of_items_in_first_condition,
    number_of_items_in_second_condition,
    number_of_shared_items,
    jaccard_similarity
  ) %>%
  pivot_wider(
    names_from = analysis_level,
    values_from = c(
      number_of_items_in_first_condition,
      number_of_items_in_second_condition,
      number_of_shared_items,
      jaccard_similarity
    )
  )

write.csv(
  summary_table_wide,
  paste0(
    "Data/jaccard_similarity_wide_summary_for_manuscript_",
    analysis_label,
    ".csv"
  ),
  row.names = FALSE
)

################################################################################
# PLOTTING ####
################################################################################


# PREPARE DATA FOR PAIRED DOT PLOT ---------------------------------------------

plot_data <- summary_table %>%
  mutate(
    comparison_label = factor(
      comparison_label,
      levels = c(
        "Aggressive vs Evasive",
        "Threat Approach vs Charge",
        "Retreat From vs Full Retreat"
      )
    ),
    analysis_level = factor(
      analysis_level,
      levels = c("Posture units", "Posture combinations")
    )
  )


# CREATE  PAIRED DOT PLOT ------------------------------------------------------
#
# For each comparison, the plot shows:
# - Jaccard similarity for posture units
# - Jaccard similarity for posture combinations
#
# The two points for each comparison are connected with a line.


jaccard_similarity_plot <- ggplot(
  plot_data,
  aes(
    x = comparison_label,
    y = jaccard_similarity,
    group = comparison_label
  )
) +
  geom_line(linewidth = 0.8, colour = "grey60") +
  geom_point(aes(shape = analysis_level), size = 3, colour = "black") +
  geom_point(aes(fill = analysis_level), shape = 21, size = 3, colour = "black") +
  coord_cartesian(ylim = c(0, 1)) +
  labs(
    x = "Behavioural comparison",
    y = "Jaccard similarity",
    shape = "Analysis level",
    fill = "Analysis level"
  ) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 20, hjust = 1)
  )


# SAVE THE PLOT

ggsave(
  filename = paste0(
    "Figures/jaccard_similarity_paired_dot_plot_",
    analysis_label,
    ".png"
  ),
  plot = jaccard_similarity_plot,
  width = 8,
  height = 5,
  dpi = 300
)



cat("\nJaccard similarity summary table:\n")
print(summary_table)

cat("\nShared posture items table:\n")
print(shared_items_table)