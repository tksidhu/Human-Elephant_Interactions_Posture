### Elephant Interspecific Posture Project: NetFACS analysis of elephant-human interaction posture data - specificity and probability networks
### Based on script by Kate Lewis NetFACS analysis of EquiFACS horse-horse data - specificity and probability networks https://osf.io/xtngb
# Created on: 31/01/2026
# Updated on: 29/04/2026



################################################################################

## Prepare environment ##

# Clear environment
rm(list=ls())
################################################################################

## Install packages ##


# only need to install package once
# will install development version of NetFACS: v0.5.0.9001
remove.packages("NetFACS")
#install.packages("remotes")
library(remotes)
remotes::install_github("NetFACS/NetFACS", ref = "73c2a29b")

#install.packages("tidyverse")
library(tidyverse)
library(NetFACS)
library(ggraph)


################################################################################

## Upload and upsample data ##

# upload data
full.data <- read.csv("Data/InterspecificPosture_ForNetFACS.csv")


# UPSAMPLE - as imbalanced number of observations per group causes specificity results to be biased

# First check current numbers of each behaviour
head(full.data %>% count(CSubcat), n=22)

#CSubcat   n
#1 Aggressive 590
#2    Evasive 877

# randomly upsample minority conditions to have the same number of observations as the majority condition

set.seed(3)

full.data.upsampled <- upsample(full.data, 
                                condition = full.data$CSubcat)
# check it has worked
print(full.data.upsampled %>% count(CSubcat), n=22) # all conditions now have 877 observations


# SPLIT full.data.upsampled into seperate DATA AND INFO dfs (needed in this format for running multi.facs)
au.info <- full.data.upsampled %>% select(X:Activity)
au.data <- full.data.upsampled %>% select(EFold:HfStToe)


# check same number of rows in each
nrow(au.data)
nrow(au.info)
#1754

# convert data to numeric, NA coercion is ok
au.data <- 
  au.data %>% 
  mutate(across(everything(), as.numeric)) %>% 
  as.matrix()

head(au.data)


##################################### ANALYSIS BY BEHAVIOURAL GROUPS ###########


#### WITH MULTIFACS ####


set.seed(20266) 
# this code is what netfacs.multiple does under the hood
# I'm coding it manually here because netfacs.multiple does not currently work when the data has NAs.
conditions <- sort(unique(au.info$CSubcat))
ran.trials <- 1000
multi.facsCCspecIP <- lapply(conditions, function(x) {
  xx <- netfacs_na(
    data = au.data,
    condition = au.info$CSubcat,
    test.condition = x,
    ran.trials = ran.trials, 
    combination.size = 2,
    random.level = au.info$RC,            # add record code as random level
    use_parallel = TRUE,
    n_cores = parallel::detectCores()-1
  )
  return(xx)
})
names(multi.facsCCspecIP) <- conditions
# set class and attributes
multi.facsCCspecIP <- structure(
  multi.facsCCspecIP, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facsCCspecIP, file="multi.facsCCspecIP.rds")

# load multi.facs object
multi.facsCCspecIP <- readRDS("multi.facsCCspecIP.rds")


# extract overall results with pvalues
(resCCspecIP <- netfacs_extract(multi.facsCCspecIP))
view(resCCspecIP)

write.csv(resCCspecIP, "Data/NetFACSExtractMultiFacsResContextsforSpecificityIP.csv")

################################################################################

#### CALCULATING SPECIFICITY ####

library(dplyr)

# netfacs() function no longer calculates specificity, so it has to be calculated separately
# imbalanced number of observations per group causes specificity results to be biased


# calculate specificity from netfacs results 
set.seed(4)
sp <- specificity(
  multi.facsCCspecIP, 
  combination.size = 2, 
  upsample = TRUE # makes sure data is upsampled before calculating specificity. 
  # If FALSE, will calculate specificity on original imbalanced data.
)


# view combinations with top 5 highest specificity per context
sp1C <- sp %>% 
  group_by(condition) %>% 
  slice_max(order_by = specificity, n = 5)

# view combinations with top 5 observed probabilities per context
sp %>% 
  group_by(condition) %>% 
  slice_max(order_by = observed.prob, n = 5)

# consider filtering for combinations that are common AND have high specificity
sp3C <- sp %>% 
  filter(
    observed.prob >= 0.5, # combinations present in at least 50% of obs
    specificity >= 0.5, 
  ) 

# save spec results
write.csv(sp, "Data/SpecifictyContextsIPRes.csv")

# plot networks 
multi.net <- multiple_netfacs_network(multi.facsCCspecIP, min.prob = 0.15)
multi.net.plot <- multiple_network_plot(multi.net)

jpeg("Figures/MultiNetIP.jpeg")
multi.net.plot
dev.off()


ag.net <- netfacs_network(multi.facsCCspecIP$Aggressive,  min.prob = 0.15) 
ag.net.plot <- network_plot(ag.net, title = "Aggressive", plot.bubbles = TRUE)

jpeg("Figures/AgProbNetIP.jpeg")
ag.net.plot
dev.off()

ev.net <- netfacs_network(multi.facsCCspecIP$Evasive,  min.prob = 0.15) 
ev.net.plot <- network_plot(ev.net, title = "Evasive", plot.bubbles = TRUE)

jpeg("Figures/EvProbNetIP.jpeg")
ev.net.plot
dev.off()

################################################################################

#### SPECIFICITY and PROBABILITY OVERLAP NETWORKS ####


overlap.net <- overlap_network(
  sp,
  min.prob = 0, # minimum probability of a connection to be included
  min.count = 3, # minimum count of co-occurrences for a connection to be included
  significance = 0.01, # significance level for combinations to be considered
  clusters = FALSE, # should the bipartite network be clustered
  plot.bubbles = TRUE,
)

MultiNetSpecificity <- plot(overlap.net$specificity)

jpeg("Figures/MultiNetSpecificityIP.jpeg")
MultiNetSpecificity
dev.off()

MultiNetOccuranceProb <- plot(overlap.net$occurrence)

jpeg("Figures/MultiNetOccuranceProb.jpeg")
MultiNetOccuranceProb
dev.off()


# CREATE CUSTOM PLOTS

min_prob <- 0.1

d2 <- 
  sp |> 
  rename(context = condition,
         count = count) %>%
  # keep single AUs only
  filter(!str_detect(combination, "_")) |> 
  filter(
    combination.size == 1,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, specificity) 

gl <- 
  d2 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()

au_color <- "steelblue"
context_color <- "salmon"

gl2 <-
  gl %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout
gl2b <-
  gl2 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr"
  )

edge_color <- "#404040"
context_color <- "#0f85a0"
au_color <- "#ed8b00"
node_text_size <- 3.4
theme_text_size <- 14

gl3 <-
  gl2b %>%
  ggraph() +
  geom_edge_fan(
    aes(alpha = specificity,
        width = specificity),
    colour = edge_color
  ) +
  geom_node_label(
    aes(label = name,
        fontface = shape),
    color = gl2b$color,
    size = node_text_size,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Specificity:",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Specificity:",
    range = c(1, 3.5),
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  coord_cartesian(clip = "off") +
  theme(
    plot.title = element_text(
      face = "plain",
      size = theme_text_size,
      vjust = -5
    ),
    legend.text = element_text(size = theme_text_size),
    legend.title = element_text(size = theme_text_size),
    plot.margin = grid::unit(c(10, 20, 10, 20), "mm"),
    legend.position = c(0.05, 0.05),
    legend.justification = c("left", "bottom")
  )

# Save the plot
ggsave(
  "Figures/SpecificityNetPlotIP.png",
  plot = gl3,
  width = 10,
  height = 8,
  dpi = 300,
  bg = "white"
)

# DO AGAIN FOR COMBOS OF 2

# CREATE CUSTOM PLOTS

min_prob <- 0.1

d2 <- 
  sp |> 
  rename(context = condition,
         count = count) %>%
  # pairs only
  filter(
    combination.size == 2,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, specificity) 

gl <- 
  d2 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()

au_color="steelblue"
context_color = "salmon"

gl2 <-
  gl %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout first so the we can access the coordinates
gl2b <-
  gl2 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr",
    niter = 2000
  )

gl3 <-
  gl2b %>%
  ggraph() +
  geom_edge_fan(
    aes(alpha = specificity,
        width = specificity),
    colour = edge_color
  ) +
  geom_node_label(
    aes(label = name,
        fontface = shape),
    color = gl2b$color,
    size = node_text_size,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Specificity:",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Specificity:",
    range = c(1, 3.5),
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  coord_cartesian(clip = "off") +
  theme(
    legend.text = element_text(size = theme_text_size),
    legend.title = element_text(size = theme_text_size),
    plot.margin = grid::unit(c(15, 35, 15, 35), "mm"),
    legend.position = c(0.95, 0.05),
    legend.justification = c("right", "bottom")
  )

ggsave(
  "Figures/PAIRSSpecificityNetPlotIP.png",
  plot = gl3,
  width = 14,
  height = 9,
  dpi = 300,
  bg = "white"
)

#overlap_net_patch <-
#  patchwork::wrap_plots(gl3) +
#  patchwork::plot_layout(ncol = 1, guides = "collect") &
# theme(legend.position = "bottom")





## customised probability plot


p2 <- 
  sp |> 
  rename(context = condition,
         count = count) %>%
  # keep single AUs only
  filter(!str_detect(combination, "_")) |> 
  filter(
    combination.size == 1,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, observed.prob) 

op <- 
  p2 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()


au_color="steelblue"
context_color = "salmon"

op2 <-
  op %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout first so the we can access the coordinates
op2b <-
  op2 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr"
  )


edge_color = "#404040"
context_color = "#0f85a0"
au_color = "#ed8b00"
node_text_size = 4
theme_text_size = 14

(op3 <-
    op2b %>%
    ggraph() +
    geom_edge_fan(
      aes(alpha = observed.prob,
          width = observed.prob),
      colour = edge_color,
    ) +
    geom_node_label(
      aes(label = name,
          fontface = shape),
      # color = .x[["color"]],
      color = op2b$color,
      size = node_text_size,
      show.legend = FALSE
    ) +
    theme_graph(
      base_family = "sans"
    ) +
    scale_edge_alpha_continuous(
      name = "Occurrence Probability",
      limits = c(0,1),
      breaks = c(0.25,0.5,0.75)
    ) +
    scale_edge_width(
      name = "Occurrence Probability",
      range = c(1, 3.5),
      limits = c(0,1),
      breaks = c(0.25,0.5,0.75)
    ) +
    # so that nodes are not cut off when saving
    # coord_cartesian(
    #   xlim = c(min(.x$x) - 0.35, max(.x$x) + 0.35),
    #   ylim = c(min(.x$y) - 0.35, max(.x$y) + 0.35)
    # ) +
    theme(
      plot.title = element_text(
        face = "plain",
        size = theme_text_size,
        vjust = -5),
      legend.text = element_text(size = theme_text_size),
      legend.title = element_text(size = theme_text_size),
      plot.margin = grid::unit(c(-1,-1,-1,-1), "mm"),
      legend.position = c(0.2,0.2)
    )
)

# Save the plot
ggsave("Figures/ProbNetPlotIP.png", plot = op3, width = 10, height = 8, dpi = 300)


#overlap_net_patch <-
#  patchwork::wrap_plots(gl3) +
#  patchwork::plot_layout(ncol = 1, guides = "collect") &
# theme(legend.position = "bottom")

################################################################################

#### SPECIFICITY VIOLIN PLOTS ####


# summarise specificity results
spIP.summary <- 
  sp %>% 
  # optional filtering. 
  # The combination count should be at least the same number as the number of conditions. 
  # Otherwise an AU combination that is only observed once will have a specificity of 1, 
  # but only because it never had the chance to be observed in another context.
  filter(
    observed.prob >= 0.10, # combination observed in >= 10% of cases
    count >= length(unique(sp$condition))
  ) %>%
  group_by(condition) %>%
  summarise(across(
    specificity,
    list(
      mean = mean,
      median = median,
      min = min,
      max = max,
      sd = sd,
      n = ~n()
    ),
    .names = "{.fn}"
  ), .groups = "keep")

write.csv(spIP.summary, "Data/NetFACSSpecificityContextsIP.csv")

SpecContIP.plot <- sp %>%
  filter(
    observed.prob >= 0.10, 
    count >= length(unique(sp$condition))
  ) %>%
  ggplot(aes(condition, specificity, 
             color = condition, fill = condition)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"),
        axis.title = element_text(size = 15, face = "bold"),
        axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)),
        axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0)),
        axis.text = element_text(size = 13, color = "black")) +
  geom_violin(alpha = 0.2,
              show.legend = FALSE) +
  geom_point(position = position_jitter(width = 0.3),
             show.legend = FALSE,
             alpha = 0.15) +
  geom_point(data = spIP.summary,
             aes(condition, mean),
             show.legend = FALSE,
             fill = "white",
             color = "black",
             shape = 23,
             size = 3.5) +
  xlab("Context") +
  ylab("Specificity") +
  scale_x_discrete(
    limits = c("Aggressive", "Evasive"),
    labels = c("Aggressive", "Evasive")
  ) +
  scale_color_manual(
    values = c("Aggressive" = "violet", "Evasive" = "light green")
  ) +
  scale_fill_manual(
    values = c("Aggressive" = "violet", "Evasive" = "light green")
  )

# Save the plot
ggsave("Figures/SpecificityCSubcatViolinPlotIP.png", plot = SpecContIP.plot, width = 10, height = 8, dpi = 300)






################################################################################

### EXTRACT SIG AU/ADs FOR EACH CONTEXT ####



## AGONISTIC ##

Ag.pus1 <- netfacs_extract(
  netfacs.data = multi.facsCCspecIP$Aggressive,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Ag.pus1)
write.csv(Ag.pus1, "Data/NetFACSAgspecIP.pus.csv")

Ag.pus1 <- netfacs_extract(
  netfacs.data = multi.facsCCspecIP$Aggressive,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Ag.pus1)
write.csv(Ag.pus1, "Data/NetFACSAgspecIPPAIRS.pus.csv")


## Evasive ##

Evasive.pus1 <- netfacs_extract(
  netfacs.data = multi.facsCCspecIP$Evasive,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Evasive.pus1)
write.csv(Evasive.pus1, "Data/NetFACSEvasivespecIP.csv")

Evasive.pus1 <- netfacs_extract(
  netfacs.data = multi.facsCCspecIP$Evasive,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Evasive.pus1)
write.csv(Evasive.pus1, "Data/NetFACSEvasivespecIPPAIRS.csv")



################################################################################



## CONDITIONAL PROBABILITIES AND PLOTS ##

# get dyadic conditional probabilities
conditional.probs <- conditional_probabilities(multi.facsCCspecIP)

# split data into a list so that each element in the list is only one condition
conditional.probs.list <- 
  conditional.probs %>% 
  split(.$condition) %>% 
  map(~.x %>% select(-condition))

conditional.probs.list$Aggressive



# conditional probability network plots
net.conditional.probs <- 
  conditional.probs.list %>% 
  map(~.x %>% 
        # keep only the most common
        slice_max(order_by = count, n = 100) %>% 
        network_conditional())

net.conditional.probs$Aggressive$plot
net.conditional.probs$Evasive$plot